const About = () => {
  return (
    <div style={{ backgroundColor: 'green', width: '400px', height: '400px' }}>
      <h1>About Page</h1>
    </div>
  );
};

export default About;
