const ContactPhone = () => {
  return (
    <div style={{ backgroundColor: 'gray', width: '300px', height: '200px' }}>
      <h3>Phone Page</h3>
      050-500-5000
    </div>
  );
};

export default ContactPhone;
