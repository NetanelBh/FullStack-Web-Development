const ContactEmail = () => {
  return (
    <div style={{ backgroundColor: 'gray', width: '300px', height: '200px' }}>
      <h3>Email Page</h3>
      our.email@ggl.com
    </div>
  );
};

export default ContactEmail;
